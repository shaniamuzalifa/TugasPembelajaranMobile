package com.example.pembelajaran;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toolbar;
import android.view.View;


public class TujuanActivity extends AppCompatActivity {
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tujuan);
        setTitle("Tujuan Pembelajaran");

        ActionBar menu = getSupportActionBar();
        menu.setDisplayShowHomeEnabled(true);
    }

}